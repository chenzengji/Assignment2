package mywork;
import java.io.BufferedWriter;
import java.io.File;  
import java.io.FileWriter;
import java.io.IOException;  
import java.sql.Timestamp;  
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  
import org.jsoup.nodes.Element;  
public class Main2014302580076 {

	public static void main(String[] args)throws IOException {
		// TODO �Զ����ɵķ������
		    //��ȡ
		    String Url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen%20Sheng%20Li";  
	        Document doc = (Document) Jsoup.connect(Url).get(); 
	        //System.out.println(doc)
	        
	        String name = new String();
	        String multitem = new String();
	        String introduction = new String();
	      
	        //������ȡ
	        Element zhuaqu =doc.select("div.details").first();
	        name = zhuaqu.select("h3").get(0).text();  
	        multitem = zhuaqu.select("p").get(0).text();
	        zhuaqu =doc.select("div.details").last();
	        introduction = zhuaqu.select("p").get(1).text();  	
	        String[] item=multitem.split(" "); 
	        
	        /*for (int i = 3; i < item.length-1; i+=2) 
	            System.out.println(item[i]+item[i+1]); 
	        System.out.println(name);
	        System.out.println(multitem);
	        System.out.println(introduction);*/
	   //���     
	        BufferedWriter bW=new BufferedWriter(new FileWriter(new File("teacher.txt")));
	        bW.write(name+"\n");
	        bW.write("\n");
	        for (int i = 3; i < item.length-1; i+=2) bW.write(item[i]+item[i+1]+"\n");
	        bW.write(introduction+"\n");
	        bW.close();

	   
	}

}
